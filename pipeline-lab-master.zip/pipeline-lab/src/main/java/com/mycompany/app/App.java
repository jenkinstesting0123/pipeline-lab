package com.mycompany.app;

/**
 * Hello world!
 *
 */
public final class App {
    /** main entry to hello world.
     *
     * @param args command line arguments
     */
    public static void main(final String[] args) {
        System.out.println("Hello World!");
    }
    /** Intentionally private constructor. */
    private App() { }
}
